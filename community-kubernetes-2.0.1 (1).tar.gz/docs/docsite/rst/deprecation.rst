******************
Deprecation Notice
******************

The ``community.kubernetes`` collection has been deprecated. Please use the `kubernetes.core collection <https://galaxy.ansible.com/kubernetes/core>`_ instead.
